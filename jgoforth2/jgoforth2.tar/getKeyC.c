/* 
* 
*/
#include <stdio.h>

int main( int argc, char **argv)
{

char buffer[1000];
int count[256], j;

if( argc < 1)
{
	fprintf(stderr, "Usage is \n< infile > output \n");
	return(1);
}

//intitalize count array
for( j=0; j<256; j++)
{
	count[j] = 0;
}

// read input
while( fgets( buffer, sizeof(buffer), stdin) != (char *)0)
{
	int i; 
        char t;

	for( i=0; i< 1000; i++)
	{
// the two possible conditions for end of line 
	if( buffer[i] == '\n') break;
	if( buffer[i] == '\0') break;
	t = tolower(buffer[i]);
	if( t < 'a' || t > 'z') continue;
	
	// cast as integar and increment count posistion of t
	count[(int)t]+=1;

	}

}
// initalize variable to hold maximum number of occurances
int max = 0;
char maxindex;
for(j =0; j<256; j++) 
{	
	// if count[j] is bigger than max, assign j
	if(count[j] > max){
		max = count[j];
		maxindex = (char)j;
	}
}

printf("%c occurs the most at %d times\n", maxindex, max);

int key;
char e = 'e';

key = 26 + ( (int)e - (int)maxindex );

printf("Key for Cipher: %d\n", key);

}
