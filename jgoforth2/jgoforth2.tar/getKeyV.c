/* 
* 
*/
#include <stdio.h>
#include <string.h>

int main( int argc, char **argv)
{

char buffer1[1000], buffer2[1000];

if( argc < 1)
{
	fprintf(stderr, "Usage is \n< infile > output \n");
	return(1);
}
long int filepos;

// Create variables to hold string that occurs the most
// and how many times it occurs
char moststr[3];
int mostoccur = 0;

// read input
while( fgets( buffer1, sizeof(buffer1), stdin) != (char *)0)
{
	
	int i;
        char t;
	// initialize string to hold 
	char str1[3]= {' ', ' ', '\0'};
	for( i=0; i< 1000; i++)
	{
	
	// the two possible conditions for end of line 
	if( buffer1[i] == '\n') break;
	if( buffer1[i] == '\0') break;
	if( buffer1[i+1] == '\n') break;
	if( buffer1[i+1] == '\0') break;
	t = tolower(buffer1[i]);
	if( t < 'a' || t > 'z') continue;
	// create string with two letters
	str1[0] = buffer1[i];
	str1[1] = buffer1[i+1];
	// Create a variable to count the occurances
	int strcount = 0;
	// record current file posistion
	filepos = ftell(stdin);
	// reset the file posistion
	fseek(stdin, 0L, SEEK_SET);
	// iterate through file and find out number of occurances
	while( fgets( buffer2, sizeof(buffer2), stdin) != (char *)0)
	{
		int j;
		char s;
		char str2[3] = {' ', ' ', '\0'};
		for( j=0; j <1000; j++) 
		{
			if ( buffer2[j] == '\n') break;
			if ( buffer2[j] == '\0') break;
			if ( buffer2[j+1] == '\n') break;
			if ( buffer2[j+1] == '\0') break;
			char str2[3]= {buffer2[j], buffer2[j+1], '\0'};
			if (strcmp(str1, str2) == 0)
			{
				strcount++;
			}
		}
	}
	// check if string occurs most
	if(mostoccur < strcount) {
		mostoccur = strcount;
		moststr[0] = str1[0];
		moststr[1] = str1[1];
		moststr[2] = str1[2];
	}
	// return to postion in file
	fseek(stdin, filepos, SEEK_SET);
	}
	}
printf("%s appears %d time\n", moststr, mostoccur);
}

