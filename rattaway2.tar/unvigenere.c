/*
 * Author: Robert Attaway
 * 
 * Description: To use a nonbrute force way to break the vigenerer cipher using 
 *              what was discovered in assignments 1 and 2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void createFrequencyTable(char);
int findCeaserOffset();
void readSourceFile(char*);
void standardizeInput();

char passagestd[8000];
char passage[8000];
char EnglishFrequencyTable[] = "etaoinshrdlcumwfgypbvkjxqz";
char* encryptedString;
int frequencies[26]={[0 ... 25] = 0};

int main(int count, char* argc[])
{
  readSourceFile(argc[1]);
  standardizeInput();
  int pos, startPos;
  for(startPos=0;startPos<11;startPos++)
  {
    for(pos=startPos;pos<strlen(passagestd);pos+=11)
    {
      createFrequencyTable(passagestd[pos]);
    }
    printf("Ceaser offset for character position %d is %d\n", startPos, findCeaserOffset());
    // clear out old frequencies
    int i;
    for(i=0;i<26;i++)
    {
      frequencies[i]=0;
    }
  }
  return (0);
}

/* remove all of the extra characters that do not matter and have one single string
   that will be used to compare with itself to find the period
*/
void standardizeInput()
{
  int didx = 0, sidx = 0;
  while(passage[sidx] != '\0')
  {
    if(passage[sidx] >= 'a' && passage[sidx] <= 'z')
    {
      passagestd[didx++] = passage[sidx];
    }
    sidx++;
  }
}
/* Read the fild into one single char* variable */
void readSourceFile(char* file)
{
  FILE * sourceFile;
  sourceFile = fopen(file, "r");
  fread (passage, 8000, 8000, sourceFile  );
  fclose(sourceFile);
}

void createFrequencyTable(char ch)
{
  if(tolower(ch)>='a' & tolower(ch) <= 'z')
  { 
   frequencies[tolower(ch)-97]++;
  }
}
int findCeaserOffset()
{
  int idx, max=0, maxidx;
  max = frequencies[0];

  for(idx=1; idx<26;idx++)
  {
    if(frequencies[idx] > max)
    { 
      max=frequencies[idx];
      maxidx=idx;
    }
  }
  return maxidx;
}
