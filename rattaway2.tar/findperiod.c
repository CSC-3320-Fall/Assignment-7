/*
 * Author: Robert Attaway
 * 
 * Description: To use a nonbrute force way to find the period of a vigenere cipher 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* function definitions. I skipped the custom.h file for simplicity */
void readSourceFile(char*);
void standardizeInput();
void findPeriod();

/* working variables */
const int SEARCH_PERIODS = 20;
int frequencies[26]={[0 ... 25] = 0};
int periodCounts[20]={[0 ... 19] = 0};

char passagestd[8000];
char passage[8000];

int main(int count, char* argc[])
{
  readSourceFile(argc[1]);
  standardizeInput();
  findPeriod();

  int x, thePeriod=0, testValue=periodCounts[0];
  for(x=1;x<SEARCH_PERIODS;x++)
  {
    if(periodCounts[x] > testValue)
    {
      thePeriod = x;
      testValue = periodCounts[x];
    }
  }
  printf("\nThe period for the input file is %d. The frequency for the period is %d\n", thePeriod + 1, periodCounts[thePeriod] );
  return (0);
}

/* simple loop to compare the two strings based on size and periods */
void findPeriod()
{
  int l = strlen(passagestd);
  int outer, inner;
  for(outer=0;outer<SEARCH_PERIODS;outer++)
  {
    for(inner=0;inner<l;inner++)
    {
      if(passagestd[inner] == passage[(inner + 1 + outer)%l])
        periodCounts[outer]++;
    }
  }
}

/* remove all of the extra characters that do not matter and have one single string
   that will be used to compare with itself to find the period
*/
void standardizeInput()
{
  int didx = 0, sidx = 0;
  while(passage[sidx] != '\0')
  {
    if(passage[sidx] >= 'a' && passage[sidx] <= 'z')
    {
      passagestd[didx++] = passage[sidx];
    }
    sidx++;
  }
}

/* Read the fild into one single char* variable */
void readSourceFile(char* file)
{
  FILE * sourceFile;
  sourceFile = fopen(file, "r");
  fread (passage, 8000, 8000, sourceFile  );
  fclose(sourceFile);
}
