
#include <stdio.h>

int main( int argc, char **argv)
{

char string[2000];
int key[10];
int i,e,nkey;

if( argc < 3)
{
        fprintf(stderr);
        return(1);
}
sscanf(argv[1],"%d",&nkey); 

if( nkey > 10) nkey = 10;
for( i=0; i< nkey; i++)
{
   sscanf(argv[1+i+1],"%d", &key[i]);
    key[i] = key[i]%26;
}

        e = 0;

while( fgets( buffer, sizeof(buffer), stdin) != (char *)0)
{
        int i,j; 
       
        for( i=0; i< 1000; i++)
        {
/* the two possible conditions for end of line */
        if( buffer[i] == '\n') break;
        if( buffer[i] == '\0') break;
        d = tolower(buffer[i]);
        if( d < 'a' || d > 'z') continue;


        j = d-'a'; /* set to zero */

        j = (j+key[e++])%26;
        e = e %nkey;

        d = j + 'a';
        putchar(d);
        }
        putchar('\n');

}
      if(key !=d)
   {
    printf("the period of the key is: " key);
}
     } 
